package com.igate.contactbook.exception;

public class ContactBookException extends Exception
{

	public ContactBookException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
